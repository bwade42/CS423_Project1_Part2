﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThePredator : Agent {
	
	public float timeBetweenDecisionsAtInference;
    public float sightDistance;
    public float turnDegree;
    public float speed;
    public GameObject monitor;

    private MainAcademy academy;
    private predatorVisualSystem visualSystem;
    private GameObject currentTargetPrey;
    private GameObject lastKill;
    private int killCount; 
    private float timeSinceDecision;
    private GameObject arena;
    private float arenaRadius;

	// Use this for initialization
	void Start () 
	{
		
	}
	public override void InitializeAgent()
	{
		academy = FindObjectOfType(typeof(MainAcademy)) as MainAcademy;
        visualSystem = this.transform.Find("predatorVisualSystem").GetComponent<predatorVisualSystem>();
        arena = GameObject.Find("Arena");
        arenaRadius = arena.GetComponent<MeshCollider>().bounds.extents.x;
        Debug.Log("Arena Radius = " + arenaRadius);

    }

/************************************************************************************************************/
/* Here we should reset the Predator if:								  									   
/*	The Academy has reset after 2000 time steps         
/***********************************************************************************************************/
	public override void AgentReset()
	{
        currentTargetPrey = null;
        lastKill = null;
        killCount = 0;
    }
/**************************************************************************************************************/
/* The predator should collect these observations 							 
/* 1. How close it is to the edge of the arena																
/* 2. The feedback from its visual system 
/*************************************************************************************************************/	
	public override void CollectObservations()
	{
        AddVectorObs(detectVisibleObjects());

        // Distance to edges of platform
        //Debug.Log("position relative to edge = (" + (this.transform.position.x) / arenaRadius + "," + (this.transform.position.z) / arenaRadius + ")");

        AddVectorObs((this.transform.position.x) / arenaRadius);
        AddVectorObs((this.transform.position.z) / arenaRadius);

        Monitor.Log("Reward", GetCumulativeReward(), MonitorType.text, monitor.transform);
    }

    float[] detectVisibleObjects()
    {
        Collider[] visibleObjectColliders = Physics.OverlapSphere(this.transform.position, sightDistance);
        Dictionary<float, GameObject> visibleObjects = new Dictionary<float, GameObject>();

        for (int i = 0; i < visibleObjectColliders.Length; i++)
        {
            GameObject nextObject = visibleObjectColliders[i].gameObject;

            if (nextObject.tag != "prey") //Changing this in the prey agent script will allow it to detect predators too
            {
                continue;
            }

            Vector3 nextObjectPosition = nextObject.transform.position;
            float angleTowardObject = Vector3.SignedAngle(this.transform.forward * -1, this.transform.position - nextObjectPosition, this.transform.up);
            //Debug.Log("Adding: " + nextObjectTag + " towards: " + angleTowardObject);
            if (!visibleObjects.ContainsKey(angleTowardObject))
            {
                visibleObjects.Add(angleTowardObject, nextObject);
            }
        }

        return visualSystem.processVisualFeedback(visibleObjects);
    }

    //Check to see if the predator is close enough to any of the visible prey to attempt an attack
    //Returns a prey target that is close enough to attack or null if it is not close enough to any prey
    private GameObject isCloseEnoughToAttack()
    {
        GameObject targetPrey = null;

        visualSystem.visiblePrey.ForEach(delegate (GameObject nextPrey)
        {
            float distanceToPrey = Vector3.Distance(this.transform.position, nextPrey.transform.position);
            //Debug.Log("distance to prey = " + distanceToPrey);
            //if (distanceToPrey <= 5)
            if (distanceToPrey <= 5f)
            {
                //Debug.Log("Found prey close enough to attack!");
                targetPrey = nextPrey;
            }
        });

        return targetPrey;
    }

    //Give the probability of successfully capturing the prey. The influence of swarm size simulates the predator confusion effect.
    public float getPreyCaptureProbability(GameObject targetPrey)
    {
        int preyCloseToTarget = 0;

        visualSystem.visiblePrey.ForEach(delegate (GameObject prey)
        {
            float distanceBetweenPrey = Vector3.Distance(targetPrey.transform.position, prey.transform.position);

            //The prey will count itself as part of the swarm. This avoids dividing by zero below.
            if (distanceBetweenPrey <= 30)
            {
                preyCloseToTarget++;
            }
        });

        //Debug.Log("prey close to target = " + preyCloseToTarget);
        float captureProbability = 1f / preyCloseToTarget;
        //Debug.Log("preyCaptureProbability = " + captureProbability);
        return captureProbability;
    }

    //True if the attack was successful, otherwise false
    public bool attackPrey(GameObject targetPrey)
    {
        float chanceOfSuccess = getPreyCaptureProbability(targetPrey);
        float outcome = Random.value;

        if (outcome <= chanceOfSuccess)
        {
            lastKill = targetPrey;
            //Debug.Log("attack success: chance of success = " + chanceOfSuccess + " , outcome = " + outcome);
            return true;
        }
        //Debug.Log("attack fail: chance of success = " + chanceOfSuccess + " , outcome = " + outcome);
        return false;
    }

    private bool positionOutofBounds()
    {
        Vector3 checkPosition = this.transform.position + this.transform.forward;

        //Debug.Log("nextPosition = (" + Mathf.Abs(checkPosition.x) + ", " + Mathf.Abs(checkPosition.z) + ")");

        if(Mathf.Abs(checkPosition.x) > arenaRadius || Mathf.Abs(checkPosition.z) > arenaRadius)
        {
            //AddReward(-0.1f);
            //Debug.Log("Position out of bounds!!");
            return true;
        }

        return false;
    }

    /******************************************************************************************************/
    /******************************************************************************************************/
	public override void AgentAction(float[] vectorAction,string textAction)
	{

		int action = Mathf.FloorToInt (vectorAction [0]);

        //If Action == 0, then do nothing, otherwise move.
        if (action > 0)
        {
            //Rotate if turning
            if (action == 2)
            {
                this.transform.Rotate(Vector3.up, turnDegree * -1);
            }
            else if (action == 3)
            {
                this.transform.Rotate(Vector3.up, turnDegree);
            }

            if (!positionOutofBounds())
            {
                //Move forward
                this.transform.position += this.transform.forward*speed;
            }
        }

        //Put the attack cooldown code here

        //Try to target a nearby prey
        currentTargetPrey = isCloseEnoughToAttack();
        bool attackResult = false;

        //If there is a prey close enough to attack, attack it
        if (currentTargetPrey != null)
        {
            attackResult = attackPrey(currentTargetPrey);
        }

        if (attackResult)
        {
            //The prey that was killed should be set as last kill
            killCount++;
            AddReward(1.0f);
            //Debug.Log("kill count = " + killCount);
            lastKill.GetComponent<preyAgent>().isDead();
            //lastKill.SetActive(false);
            //Done();
            //academy.AcademyReset();
        }

        if(visualSystem.visiblePrey.Count > 0)
        {
            AddReward(0.01f);
        }

        AddReward(-0.0005f); // 1f/simulation time steps to encourage predator to hurry        
    }

/******************************************************************************************************/
/**              These functions are useful if you want tick the "On Demad Decisions"                **/
/******************************************************************************************************/
	/*
	public void FixedUpdate()
	{
		WaitTimeInference();
	}

	private void WaitTimeInference()
	{
		if (!academy.GetIsInference())
		{
			RequestDecision();
		}
		else
		{
			if (timeSinceDecision >= timeBetweenDecisionsAtInference)
			{
				timeSinceDecision = 0f;
				RequestDecision();
			}
			else
			{
				timeSinceDecision += Time.fixedDeltaTime;
			}
		}
	}

  */
}
